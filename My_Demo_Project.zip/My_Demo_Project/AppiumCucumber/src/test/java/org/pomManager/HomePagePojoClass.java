package org.pomManager;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.utilityPackage.BaseClass;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class HomePagePojoClass extends BaseClass{
	
	public HomePagePojoClass() {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(accessibility = "Preference")
	private WebElement preferance;

	public WebElement getPreferance() {
		return preferance;
	}

	public void setPreferance(WebElement preferance) {
		this.preferance = preferance;
	}
	
	
	

}
