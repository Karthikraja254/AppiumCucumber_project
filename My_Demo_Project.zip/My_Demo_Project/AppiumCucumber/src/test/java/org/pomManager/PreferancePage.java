package org.pomManager;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.utilityPackage.BaseClass;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class PreferancePage extends BaseClass{
	
	public PreferancePage() {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(accessibility = "3. Preference dependencies")
	private WebElement preferenceDependencies;

	public WebElement getPreferenceDependencies() {
		return preferenceDependencies;
	}

	public void setPreferenceDependencies(WebElement preferenceDependencies) {
		this.preferenceDependencies = preferenceDependencies;
	}
	

}
