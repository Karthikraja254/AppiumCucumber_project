package org.runner;

import java.io.File;
import java.util.*;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

public class JVMReporting {
	
	public static void generateReporting(String reportfile) {
		File file = new File("C:\\Users\\HP\\eclipse-workspace\\NewWork\\AppiumCucumber\\Report");
		Configuration config = new Configuration(file,"Automate the Wifi Futionality");
		config.addClassifications("browserName", "chrome");
		config.addClassifications("version", "119");
		config.addClassifications("sprint 2", "2 weeks");
		config.addClassifications("OS", "windows10");
		
		List<String> li = new ArrayList<String>();
		li.add(reportfile);
		
		ReportBuilder builder = new ReportBuilder(li,config);
		builder.generateReports();
		
	}
}
