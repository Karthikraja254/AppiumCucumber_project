package org.steps;



import java.net.MalformedURLException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.pomManager.HomePagePojoClass;
import org.pomManager.PreferancePage;
import org.pomManager.WifiSetting;
import org.utilityPackage.BaseClass;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import junit.framework.Assert;

public class LoginStespsClass extends BaseClass{
	
	AppiumDriverLocalService service;
	HomePagePojoClass hp;
	PreferancePage pp;
	WifiSetting w;
	Boolean bool;
	
	@Given("I have launch the application")
	public void i_have_launch_the_application() throws MalformedURLException {
		service = buildAppiumService();
		service.start();
		appLaunch("POCO M6 5G", "Android", "uiautomator2", "C:\\Users\\HP\\eclipse-workspace\\NewWork\\AppiumCucumber\\src\\test\\resources\\ApiDemos-debug.apk");
	}
	
	
	@When("I have selected Preference and clicked Preference dependencies")
	public void i_have_selected_preference_and_clicked_preference_dependencies() {
		hp = new HomePagePojoClass();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		hp.getPreferance().click();
	}
	
	
	@When("I have click the check button and enterd the {string}")
	public void i_have_click_the_check_button_and_enterd_the(String wifi) {
		
		pp = new PreferancePage();
		pp.getPreferenceDependencies().click();
		w = new WifiSetting();
		w.getCheckBox().click();
		w.getWifiOption().click();
		w.getTextBox().sendKeys(wifi);
		w.getOkButton().click();
		
	}
	@Then("the name should be accepted")
	public void the_name_should_be_accepted() {
		try {
			
			w.getOkButton().click();;
			bool = true;
		}
		catch(Exception e){
			bool = false;
		}
		
	    Assert.assertFalse(bool);
	    System.out.println("Validation success");
	}
	
}
